# Risk of Smirk
Adds support for using the :smirk_cat: emoji in chat. Send :smirk_cat: in chat and a smirking cat emoji will be overlayed onto it.

# Credits
MonsterSkinMan - idea
pseudopulse - smirking cat emoji support
